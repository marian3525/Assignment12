#pragma once
class Test
{
public:
	Test();
	~Test();
};

