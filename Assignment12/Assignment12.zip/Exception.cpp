#include "Exception.h"

string ControllerException::getMessage()
{
	return message;
}

string RepositoryException::getMessage()
{
	return message;
}

string ValidatorException::getMessage()
{
	return message;
}
